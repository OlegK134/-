# Contribution Guide

## Tests

### non-gui tests

Not well maintained for now.

### gui tests

Unit tests under tests/gui directory can be run from Dev menu of exporter.
